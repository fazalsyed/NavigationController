//
//  FirstVC.swift
//  NavigationBar
//
//  Created by syed fazal abbas on 06/04/23.
//

import UIKit

class FirstVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
   
    @IBAction func btnFirst(_ sender: UIButton) {
        let secondVC = self.storyboard?.instantiateViewController(identifier: "SecondeVC") as! SecondeVC
               self.navigationController?.pushViewController(secondVC, animated: true)
     
    }
    
}
