//
//  ThirdVC.swift
//  NavigationBar
//
//  Created by syed fazal abbas on 06/04/23.
//

import UIKit

class ThirdVC: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnThird(_ sender: UIButton) {
        let ThirdVc = self.storyboard?.instantiateViewController(withIdentifier: "FourthVC") as! FourthVC
        self.navigationController?.pushViewController(ThirdVc, animated: true)
       
    }
}
