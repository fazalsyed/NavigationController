//
//  SecondeVC.swift
//  NavigationBar
//
//  Created by syed fazal abbas on 06/04/23.
//

import UIKit

class SecondeVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnSeconde(_ sender: UIButton) {
        let SecondeVc = self.storyboard?.instantiateViewController(withIdentifier: "ThirdVC") as! ThirdVC
        self.navigationController?.pushViewController(SecondeVc, animated: true)
    }
    
}
