//
//  FourthVC.swift
//  NavigationBar
//
//  Created by syed fazal abbas on 06/04/23.
//

import UIKit

class FourthVC: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnFourth(_ sender: UIButton) {
        let FourthVc = self.navigationController?.viewControllers[1] as! SecondeVC
        if(self.isKind(of: SecondeVC .classForCoder())){
            self.navigationController?.popToViewController(FourthVc, animated: true)
        }
        else{
            self.navigationController?.popToRootViewController(animated: true)
        }
    }
}
